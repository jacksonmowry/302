#include <iostream>
#include <vector>
#include "lab_2.hpp"
using namespace std;

unsigned long long whats_my_number_ll()
{
  return 0;
}

double whats_my_number_d()
{
  return 0;
}

unsigned int optimal()
{
  return 0;
}
