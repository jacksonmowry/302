#include <string>
#include <vector>
#include <list>
#include <algorithm>
#include <map>
#include <vector>
#include <set>
#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;

class BlackWhiteRectangles {
  public:
    int blackCount(vector <string> rectangles);
};

int BlackWhiteRectangles::blackCount(vector <string> R)
{
  return 0;
}
