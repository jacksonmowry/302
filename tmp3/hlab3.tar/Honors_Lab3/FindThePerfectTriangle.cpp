#include <string>
#include <cmath>
#include <vector>
#include <list>
#include <cmath>
#include <algorithm>
#include <map>
#include <set>
#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;

#define VIT(i, v) for (i = 0; i < v.size(); i++) 

class FindThePerfectTriangle {
  public:
    vector <int> constructTriangle(int area, int perimeter);
};

vector <int> FindThePerfectTriangle::constructTriangle(int area, int perimeter)
{
  vector <int> rv;

  return rv;
}
